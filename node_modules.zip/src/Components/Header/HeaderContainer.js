import React from 'react'
import Header from './Header'

const HeaderContainer = (props) => {
    return (
        <Header />
    )
}

export default HeaderContainer