import React from 'react'
import WeDoing from './WeDoing'

const WeDoingContainer = () => {
    return (
        <WeDoing />
    )
}

export default WeDoingContainer