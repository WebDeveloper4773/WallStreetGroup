import React from 'react'

const Vector = () => {
    return (
        <svg width="24" height="14" viewBox="0 0 24 14">
            <path  d="M12 10.0877L1.94905 0L0 1.95617L12 14L24 1.95617L22.051 0L12 10.0877Z"/>
        </svg>
    )
}

export default Vector