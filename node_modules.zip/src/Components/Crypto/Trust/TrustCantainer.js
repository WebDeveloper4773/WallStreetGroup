import React from 'react'
import Trust from './Trust'

const TrustContainer = () => {
    return (
        <Trust />
    )
}

export default TrustContainer