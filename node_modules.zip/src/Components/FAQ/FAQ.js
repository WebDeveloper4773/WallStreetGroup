import React, {useState, useEffect} from 'react'
import './FAQ.css'
import Vector from './../../Svg/Vector'
import Telegram3 from './../../Svg/Telegram3'
import classNames from 'classnames'


const FAQ = () => {
    return (
        <>
        </>
    )
}

export default FAQ