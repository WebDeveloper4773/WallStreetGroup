import React from 'react'
import CryptoMain from './CryptoMain'

const CryptoMainContainer = () => {
    return (
        <CryptoMain />
    )
}

export default CryptoMain