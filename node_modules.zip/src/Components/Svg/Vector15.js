import React from 'react'

const Vector15 = () => {
    return (
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M16 19.0877L5.94905 9L4 10.9562L16 23L28 10.9562L26.051 9L16 19.0877Z" fill="#8B8E8F"/>
        </svg>
    )
}

export default Vector15