import React from 'react'
import Stat from './Stat'

const StatContainer = () => {
    return (
        <Stat />
    )
}

export default StatContainer