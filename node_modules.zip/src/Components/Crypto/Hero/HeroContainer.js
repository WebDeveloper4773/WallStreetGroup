import React from 'react'
import Hero from './Hero'

const HeroContainer = (props) => {
    return (
        <Hero/>
    )
}

export default HeroContainer