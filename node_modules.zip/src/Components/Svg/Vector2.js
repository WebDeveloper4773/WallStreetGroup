import React from 'react'

const Vector2 = () => {
    return (
        <svg width="16" height="13" viewBox="0 0 16 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5.33333 12.8666L0 7.53325L1.86667 5.66659L5.33333 9.13325L14.1333 0.333252L16 2.19992L5.33333 12.8666Z" fill="white"/>
        </svg>

    )
}

export default Vector2